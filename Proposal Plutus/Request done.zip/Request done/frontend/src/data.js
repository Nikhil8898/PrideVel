export default [


    {
        _id: { "$oid": "61fba25215d50decdde0be65" },
        Category: " Support New Token ",
        Title: " Support XYZ ",
        Wallet_Address: "walletaddress",
        Description: "Support XYZ token",
        Status: "in-process",
        Date: "2022-02-23",
    },
]

